
### Exemples

x <- rnorm(50)
y <- rnorm(x)

### Graphique
plot(x, y)

### Graphique
plot(density(x))

1:25


suite1 <- seq(from=-5, to=10, by=2) 
suite2 <- seq(from=-5,length=15) ###sequence de longueur 15

rep(1,5)
rep(1:5, each=8)

### Arithmétique vectorielle
v <- 1:12
v+2
v*-12:-1
v + 1:3


v <- runif(12, min = 1,max = 15)

### Pour afficher directement les affectations
(v <- runif(12, min = 1,max = 15))

### Les matrices
( m <- matrix(2, 4,4))
m1 <- diag(1,4,4); m1
m*m1
m + 3
m * 7
m^2

###Pour supprimer la dernière colonne
(m<- m[,-4])

### transposée et inverse de m
t(m)
solve(m)

### Produit matriciel
m %*% m
m %*% solve(m)
?solve

v <- numeric(0)



###Exercices
Equipe <- c("Washington", "Dallas", "Chicago", "Los Angeles", 
            "St-Louis", "Détroit", "Montréal", "Boston")
MJ <- c(55,56,57,58,56,57,56,57)
V <- c(36,32,30,30,25,25,22,24)
D <- c(16,19,21,22,19,21,27,31)
DP <- c(3,5,6,6,12,11,7,2)
PTS <- c(75,69,66,66,62,61,51,50)
list(Equipe=Equipe, MJ=MJ, V= V, D=D, DP =DP, PTS=PTS)

###Création du dataframe
( classement <- data.frame(Equipe,MJ,V,D,DP,PTS))
classement$PTS

###nombre de ligne
nrow(classement)

## Extraction d'informations
classement[classement$Equipe == "Montréal",]

subset(classement, Equipe=="Montréal")

classement[7,]

class(x)

### Ajout d'une ligne 
liste <- list(Equipe="France", MJ=59, V=23, D=28, DP=8, PTS=53)
rbind(classement,liste)






v1 <- c(8,7,3)
v2 <- c(14,7,5)

###produit matriciel
outer(v1,v2)
v1*v2

###produit matriciel
v1%*% t(v2)















### EXERCICES 3.8

### 3.1

rep(1:3, each=4)
seq(from=1,to=10,by=3)
rep(x = c(0,6), times=3)
rep(1:3, times=4)

x  <- numeric(0)
j <- 0
i <- 1


### 3.3
rowSums(x)
apply(x, MARGIN = 1, FUN = mean)

cumprod(1:10)


x <- sample()
y <- rnorm(100, mean=1,sd=1)
y[(length(y)-5):length(y)]
