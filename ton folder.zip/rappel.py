#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Sep  7 09:10:42 2023

@author: Jennifer
"""

for i in range(10):  # boocle
    print(i)

    import numpy.random as npr
    while npr.binomial(1, 1/2, 1) == 0:
        print('face')
    print('pile')


def est_pair(n):
   if n % 2 == 0:
       print('pair')
   else:
       print('impair')


est_pair(5)

def estPair(n):
    if n % 2 == 0:
        return True
    else:
        return False

estPair(5)
    
    
def ispair(n):
   return n%2==0
       
ispair(5)
 
 
 
 # ex1
 # partie 1
def div_5(n):
    return n%5==0
div_5(4)

# partie2
def istriangle(a,b,c):
   return max(a,b,c)<=min(a+b,a+c,b+c)
    
istriangle(1,2,3)


# partie3
def samesign(m,n,p):
    return m*n>0 and m*p>0

samesign(1,2,3)
# partie4
def inCercle(r,n,m): #une cercle de centre O
    return n**2+m**2<=r**2

inCercle(1/4,1/2,1/2)

from math import sqrt,pi, cos, sin

def in_Cercle(r,n,m): #une cercle de centre O
    return sqrt(n**2+m**2)<=sqrt(r**2)
in_Cercle(1/4,1/2,1/2)

# ex3
# partie1 
def sommediv(n):
    L=[]
    i=1
    for i in range(1,int(n/2+1)):
        if n%i==0:
            L.append(i)
    return(L,sum(L))

sommediv(6)

# partie2
def nbparfaits(n):
    L=[]
    for i in range(1,n+1):
        s=sommediv(i)[1]
        if s==i:
            L.append(i)
            return L

def nbparfaits2(n): #AUTRE METHODE
    return[i for i in range(1,n+1) if sommediv(i)[1]==i]
# calculer le temps
#%timeit nbparfaits(1000)
#%timeit nbparfaits2(1000)

# construire un vecteur et une matrice
import numpy as np
v=np.array([1,2,3,4])
# sqrt(v) va donner un error
np.sqrt(v)

M=np.array([[1,2,3],[4,5,7],[6,8,9]])
N=np.array([[1,2,3],[4,5,7],[6,8,9]])

M.dot(N)

#EX10
#PARTI1
#ECrIRE UNE FT QUI RENVOIE M^n
def puissmat(M,n):
    d= M.shape[0] #pour une matrice carrre de dim 0 par exemple
    Mp=np.eye(d)
    for i in range(1,n+1):
        Mp=Mp.dot(M)
    return Mp


M=np.array([[1,0,2],[-1,1,1],[0,3,-5]])
puissmat(M, 0)
puissmat(M, 1)
puissmat(M,5)

poly = puissmat(M, 3) - 3*puissmat(M, 2) + 12*puissmat(M, 1) -14*puissmat(M, 0)

np.linalg.matrix_power(M, 10)
#%timeit puissmat(M,20)
#%timeit np.linalg.matrix_power(M, 20)

import numpy.random as npr
M = npr.uniform(-1,1,225).reshape((15,15))
%timeit puissmat(M,500)
%timeit np.linalg.matrix_power(M, 500)
